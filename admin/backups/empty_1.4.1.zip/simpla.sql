/* Table structure for table `articles` */
DROP TABLE IF EXISTS `articles`;

CREATE TABLE `articles` (
  `article_id` int(11) NOT NULL auto_increment,
  `header` varchar(500) NOT NULL,
  `url` varchar(255) NOT NULL,
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `annotation` text NOT NULL,
  `body` longtext NOT NULL,
  `order_num` int(11) NOT NULL default '0',
  `enabled` tinyint(1) NOT NULL default '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`article_id`),
  KEY `enabled` (`enabled`),
  KEY `order_num` (`order_num`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/* dumping data for table `articles` */
insert into `articles` values
(1,'Гаджет для гиков','gadget_for_geek','Гаджет для гиков','Гаджет для гиков','Гаджет для гиков','<p>Гаджет &mdash;  (англ. <i><span lang=\"EN\">gadget</span></i>&nbsp;&mdash; <i>приспособление)<span>&nbsp; </span></i>&mdash; <i><span> </span></i>техническое устройство, обладающее повышенной функциональностью, но с ограниченными возможностями.\r\n</p><p class=\"MsoNormal\">&nbsp;</p><p class=\"MsoNormal\">Сегодня гаджетом можно считать любой цифровой\r\nприбор, достаточно небольшой, чтобы надеть на руку или подключить к КПК\r\nили смартфонам. </p>','<p>Гаджет &mdash;  (англ. <i><span lang=\"EN\">gadget</span></i>&nbsp;&mdash; <i>приспособление)<span>&nbsp; </span></i>&mdash;&nbsp; <i><span></span></i>техническое устройство, обладающее повышенной функциональностью, но с ограниченными возможностями.\r\n</p><p class=\"MsoNormal\">Сегодня гаджетом можно считать любой цифровой\r\nприбор, достаточно небольшой, чтобы надеть на руку или подключить к КПК\r\nили смартфонам. </p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\">В\r\nпрограммном обеспечении гаджет&nbsp;&mdash; небольшое приложение, предоставляющее\r\nдополнительную информацию, например, прогноз погоды или курс валют.</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\">Есть несколько версий касательно происхождения слова &laquo;гаджет&raquo;, в том смысле в котором оно используется сейчас:</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%; margin-left: 36pt; text-indent: -18pt;\"><span style=\"font-family: Symbol;\">&middot;<span style=\"font-family: \'Times New Roman\'; font-style: normal; font-variant: normal; font-weight: normal; font-size: 7pt; line-height: normal; font-size-adjust: none; font-stretch: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span>из лексикона моряков от французского g&acirc;chette, названия части стрелкового механизма;</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%; margin-left: 36pt; text-indent: -18pt;\"><span style=\"font-family: Symbol;\">&middot;<span style=\"font-family: \'Times New Roman\'; font-style: normal; font-variant: normal; font-weight: normal; font-size: 7pt; line-height: normal; font-size-adjust: none; font-stretch: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span>от французского gag&eacute;e, маленького инструмента или аксессуара;</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%; margin-left: 36pt; text-indent: -18pt;\"><span style=\"font-family: Symbol;\">&middot;<span style=\"font-family: \'Times New Roman\'; font-style: normal; font-variant: normal; font-weight: normal; font-size: 7pt; line-height: normal; font-size-adjust: none; font-stretch: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span>от французского engager&nbsp;&mdash; &laquo;связывать одну вещь с другой&raquo;;</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%; margin-left: 36pt; text-indent: -18pt;\"><span style=\"font-family: Symbol;\">&middot;<span style=\"font-family: \'Times New Roman\'; font-style: normal; font-variant: normal; font-weight: normal; font-size: 7pt; line-height: normal; font-size-adjust: none; font-stretch: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span>от слова из шотландского инженерного жаргона gadge&nbsp;&mdash; форма измерительного инструмента;</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%; margin-left: 36pt; text-indent: -18pt;\"><span style=\"font-family: Symbol;\">&middot;<span style=\"font-family: \'Times New Roman\'; font-style: normal; font-variant: normal; font-weight: normal; font-size: 7pt; line-height: normal; font-size-adjust: none; font-stretch: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span>пружинная клемма, используемая для держания сосуда в процессе производства стекла, тоже известна как гаджет.</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%; margin-left: 36pt; text-indent: -18pt;\"><span style=\"font-family: Symbol;\">&middot;<span style=\"font-family: \'Times New Roman\'; font-style: normal; font-variant: normal; font-weight: normal; font-size: 7pt; line-height: normal; font-size-adjust: none; font-stretch: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span>и,\r\nнаконец, последняя версия: муж говорит жене: &laquo;Дорогая, я снова купил\r\nсебе очень дорогой и очень красивый плеер!&raquo; Жена: &laquo; Ну и ГАД ЖЕ Ты&raquo;\r\n(шутка)</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\">Отличительные характеристики гаджетов такие:</p>\r\n<ul type=\"disc\"><li class=\"MsoNormal\" style=\"background: #f8fcff none repeat scroll 0% 0%;\"><span>&nbsp;</span><i>Портативность</i>. Вес типичных гаджетов не превышает 300 грамм, а размеры позволяют им умещаться в карманах одежды. </li><li class=\"MsoNormal\" style=\"background: #f8fcff none repeat scroll 0% 0%;\"><i>Функциональность</i>.\r\nГаджет, помимо ожидаемых функций (например, индикация времени для\r\nчасов) содержит произвольный набор дополнительных функций (в часы может\r\nбыть встроен радиоприёмник, микрокомпьютер, плеер и.т.п.) </li><li class=\"MsoNormal\" style=\"background: #f8fcff none repeat scroll 0% 0%;\"><i>Ограниченные возможности</i>.\r\nБольшинство гаджетов не имеют возможности расширения функционала за\r\nсчёт присоединения дополнительных модулей. Также гаджеты, зачастую,\r\nкомплектуются недостаточно ёмкими аккумуляторами. Типичное время\r\nавтономной работы 8-12 часов при средне интенсивном использовании\r\nдополнительных функций. </li></ul>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\">Вот наиболее популярные гаджеты:</p>\r\n<ul type=\"disc\"><li class=\"MsoNormal\" style=\"background: #f8fcff none repeat scroll 0% 0%;\">КПК, смартфон, коммуникатор;</li><li class=\"MsoNormal\" style=\"background: #f8fcff none repeat scroll 0% 0%;\">Мобильный телефон с добавочными функциями (например, распознавание рукописного ввода илирадиоприемник);</li><li class=\"MsoNormal\" style=\"background: #f8fcff none repeat scroll 0% 0%;\"><span lang=\"EN-US\">iPod</span>&nbsp;&mdash; mp3-плеер от фирмы <span lang=\"EN-US\">Apple</span>; </li><li class=\"MsoNormal\" style=\"background: #f8fcff none repeat scroll 0% 0%;\">Авторучки с набором электронных услуг (шариковая ручка как телефон,<span>&nbsp; </span>фотоаппарат и&nbsp;т.&nbsp;п.), радиоприемники с дополнительными функциями, ноутбуки, часы, браслеты; </li><li class=\"MsoNormal\" style=\"background: #f8fcff none repeat scroll 0% 0%;\">Электронные книги; </li><li class=\"MsoNormal\" style=\"background: #f8fcff none repeat scroll 0% 0%;\">Часы </li></ul>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\">Похожую смысловую нагрузку несут в себе такие понятия как <b>гизмо</b> и <b>новелти</b>, но<span>&nbsp; </span>новелти\r\nв отличие от гаджета не имеет практической цели, а гизмо трактуется как\r\nустройство, имеющее движущие части. Например, стильные цифровые часы&nbsp;&mdash;\r\nэто гаджет, а аналоговые&nbsp;&mdash; гизмо.</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\">В\r\nкиноматографе гаджеты наиболее часто используются в шпионских фильмах,\r\nособенно в сериале про Джеймса Бонда. У супер-героев, особенно Бэтмена\r\nи Айронмена, есть огромное множество гаджетов. Известен персонаж\r\nмультфильмов Инспектор Гаджет, сказочная сила которого происходит от\r\nнабора инструментов, внедрённых в его тело. Также в мультфильмах Диснея\r\n<span lang=\"EN-US\">Chip</span> \'<span lang=\"EN-US\">n</span><span lang=\"EN-US\"> </span><span lang=\"EN-US\">Dale</span><span lang=\"EN-US\"> </span><span lang=\"EN-US\">Rescue</span><span lang=\"EN-US\"> </span><span lang=\"EN-US\">Rangers</span>, <span lang=\"EN-US\">Gadget</span><span lang=\"EN-US\"> </span><span lang=\"EN-US\">Hackwrench</span> (руск. <i>Гаечка</i>) один из главных героев умеет создавать инструменты и другую технику из мусора и старья.</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\">Если\r\nподытожить, то гаджет &ndash; это умное, полезное и красивое устройство для\r\nгика. Ну а гик &ndash; это человек, который по достоинству оценил это самое\r\nустройство.</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\"><b>Гик</b> (англ. <i><span lang=\"EN\">geek</span></i>) &mdash; эксцентричный человек, одержимый технологиями, в том числе компьютерными.</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\">Как\r\nправило, гики выпадают из традиционной общественной жизни, концентрируя\r\nсвоё время на различных высоких технологиях. Образ гиков активно\r\nэксплуатируется в кино.</p>\r\n<p style=\"background: #f8fcff none repeat scroll 0% 0%;\">Гики примерно до 1994 года составляли подавляющее большинство пользователей Сети.</p><p>&nbsp;</p>',3,1,'0000-00-00 00:00:00','2009-08-05 15:25:38'),
(3,'Камера для шлема','camera','Камера для шлема','Камера для шлема','Камера для шлема','<p><img style=\"border: 0pt none; margin: 5px; float: left;\" src=\"/files/images/articles/_cvsd-j11-8.jpg\" alt=\"camera\" height=\"150\" width=\"150\" />Нашлемная камера для активного спорта. Если вы занимаетесь активными\r\nвидами спортивной жизни и хотите это запечатлеть, а затем посмотреть на\r\nвашем компьютере или плеере, то этот гаджет 100% ищет именно Вас.</p><p>&nbsp;</p>','<p><img src=\"/files/images/articles/cvsd-j11-8.jpg\" alt=\"camera\" border=\"0\" height=\"500\" width=\"500\" /></p><p>Возможность записи видео с разрешением 640 х 480 (VGA) на 30fps,\r\nлегкая, компактная камера для шлема является уникальным изобретением\r\nдля Вас. Представьте себе игру в пейнтбол, где всё записываeтся: каждый\r\nшаг и каждый выстрел людей на поле для того, чтобы наслаждаться этими\r\nмоментами снова и снова. Или записывать себя в прыжке с самолета с\r\nпарашютом. Или скоростной спуск на лыжах или велосипеде.</p><p>&nbsp;</p><p>Каким бы видом спорта вы не занимались, камера практически подходит\r\nвсем. Простота использования и легкость крепления на стандартном шлеме.\r\nДостаточно вставить SD-карту в камеру и начать запись, это просто! BMX,\r\nтрэки, мотокросс, лыжи, сноубординг, альпинизм, спуск, ATV - всё это\r\nснимет камера! Теперь вы можете показать всем своим друзьям и семье\r\nневероятные POV кадры из ваших приключений, покажите им самые лучшие\r\nспортивные моменты.</p>',1,1,'2009-02-12 17:46:54','2009-08-28 17:56:52');

/* Table structure for table `brands` */
DROP TABLE IF EXISTS `brands`;

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY  (`brand_id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `categories` */
DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL auto_increment,
  `parent` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `single_name` varchar(255) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(255) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  `order_num` int(11) NOT NULL default '0',
  `enabled` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`category_id`),
  KEY `order_num` (`order_num`),
  KEY `parent` (`parent`),
  KEY `url` (`url`),
  KEY `enabled` (`enabled`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `currencies` */
DROP TABLE IF EXISTS `currencies`;

CREATE TABLE `currencies` (
  `currency_id` int(11) NOT NULL auto_increment,
  `main` int(1) NOT NULL default '0',
  `def` int(1) NOT NULL default '0',
  `name` varchar(20) NOT NULL default '',
  `sign` varchar(20) NOT NULL default '',
  `code` char(3) NOT NULL default '',
  `rate_from` float(6,3) NOT NULL default '1.000',
  `rate_to` float(6,3) NOT NULL default '1.000',
  PRIMARY KEY  (`currency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/* dumping data for table `currencies` */
insert into `currencies` values
(1,1,0,'доллары','$','USD','1.000','1.000'),
(4,0,1,'рубли','руб','RUR','36.000','1.000'),
(7,0,0,'wmz','wmz','WMZ','1.000','1.200'),
(8,0,0,'wmu','wmu','WMU','1.000','8.000');

/* Table structure for table `delivery_methods` */
DROP TABLE IF EXISTS `delivery_methods`;

CREATE TABLE `delivery_methods` (
  `delivery_method_id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `free_from` float(10,2) NOT NULL,
  `price` float(10,2) NOT NULL,
  `enabled` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`delivery_method_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/* dumping data for table `delivery_methods` */
insert into `delivery_methods` values
(1,'Курьерская доставка по Москве','<p>Курьерская доставка осуществляется на следующий день после оформления заказа, если товар есть в наличии. Курьерская доставка осуществляется в пределах Томска и Северска ежедневно с 10.00 до 21.00. Заказ на сумму свыше 300 рублей доставляется бесплатно.&nbsp;<br /><br />Стоимость бесплатной доставки раcсчитывается от суммы заказа с учтенной скидкой. В случае если сумма заказа после применения скидки менее 300р, осуществляется платная доставка.&nbsp;<br /><br />При сумме заказа менее 300 рублей стоимость доставки составляет от 50 рублей.</p>','10.00','2.00',1),
(2,'Самовывоз','<p>Удобный, бесплатный и быстрый способ получения заказа.</p><p>Адрес офиса: Адрес офиса: Москва, ул. Арбат, 1/3, офис 419. </p>','0.00','0.00',1),
(3,'Доставка с помощью предприятия \"Автотрейдинг\"','<p>Удобный и быстрый способ доставки в крупные города России. Посылка доставляется в офис \"Автотрейдинг\" в Вашем городе. Для получения необходимо предъявить паспорт и номер грузовой декларации (сообщит наш менеджер после отправки). Посылку желательно получить в течение 24 часов с момента прихода груза, иначе компания \"Автотрейдинг\" может взыскать с Вас дополнительную оплату за хранение. Срок доставки и стоимость Вы можете рассчитать на сайте компании.</p>','99999.00','9.00',1),
(7,'Наложенным платежом с помощью  \"Почты России\"','<p>При доставке заказа наложенным платежом с помощью \"Почты России\", вы сможете оплатить заказ непосредственно в момент получения товаров.</p>','999999.00','9.00',1);

/* Table structure for table `delivery_payment` */
DROP TABLE IF EXISTS `delivery_payment`;

CREATE TABLE `delivery_payment` (
  `delivery_method_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  PRIMARY KEY  (`delivery_method_id`,`payment_method_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Связка способом оплаты и способов доставки';

/* dumping data for table `delivery_payment` */
insert into `delivery_payment` values
(1,1),
(1,2),
(1,3),
(1,7),
(1,8),
(1,9),
(1,10),
(1,11),
(2,1),
(2,2),
(2,3),
(2,7),
(2,8),
(2,9),
(2,10),
(2,11),
(3,2),
(3,3),
(3,7),
(3,8),
(3,9),
(3,10),
(4,5),
(7,2),
(7,3),
(7,7),
(7,8),
(7,9),
(7,10);

/* Table structure for table `feedback` */
DROP TABLE IF EXISTS `feedback`;

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL auto_increment,
  `date` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY  (`feedback_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `groups` */
DROP TABLE IF EXISTS `groups`;

CREATE TABLE `groups` (
  `group_id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `discount` float(5,2) NOT NULL default '0.00',
  PRIMARY KEY  (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/* dumping data for table `groups` */
insert into `groups` values
(1,'Постоянный клиент','5.00');

/* Table structure for table `menu` */
DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `fixed` tinyint(1) default '0',
  PRIMARY KEY  (`menu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* dumping data for table `menu` */
insert into `menu` values
(1,'Другие страницы',2),
(2,'Верхнее меню',2),
(3,'Мобильная версия',0);

/* Table structure for table `modules` */
DROP TABLE IF EXISTS `modules`;

CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL auto_increment,
  `class` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `valuable` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

/* dumping data for table `modules` */
insert into `modules` values
(1,'StaticPage','Статическая страница',1),
(3,'NewsLine','Лента новостей',1),
(4,'Storefront','Каталог товаров',1),
(5,'Articles','Статьи',1),
(6,'Search','Поиск',0),
(7,'Cart','Корзина',0),
(8,'Login','Вход для пользователей',1),
(9,'Registration','Регистрация пользователя',1),
(12,'Account','Аккаунт пользователя',0),
(11,'Order','Оформление заказа',0),
(13,'Pricelist','Прайс-лист',1),
(14,'Sitemap','Карта сайта',1),
(10,'Feedback','Обратная связь',1),
(15,'Compare','Сравнение товаров',0);

/* Table structure for table `news` */
DROP TABLE IF EXISTS `news`;

CREATE TABLE `news` (
  `news_id` int(11) NOT NULL auto_increment,
  `header` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL default '',
  `date` date NOT NULL default '0000-00-00',
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `annotation` text NOT NULL,
  `body` text NOT NULL,
  `enabled` tinyint(1) NOT NULL default '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`news_id`),
  KEY `url` (`url`),
  KEY `enabled` (`enabled`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/* dumping data for table `news` */
insert into `news` values
(3,'Насадка для крана','waterlight','2009-08-05','Насадка для крана','Насадка для крана','Насадка для крана','<p><img src=\"/files/images/news/123.gif\" alt=\"water\" border=\"0\" height=\"209\" width=\"200\" /></p><p>Запуск крана довольно скучное занятие, не правда ли? Вы в свою очередь\r\nоткрываете воду, моете руки и закрываете кран. Но что если ваша\r\nводопроводная вода может излучать свет, например светло-синий или\r\nкрасный? Может, если вы используете Glow Flow Tap.</p>','<p>Запуск крана довольно скучное занятие, не правда ли? Вы в свою очередь\r\nоткрываете воду, моете руки и закрываете кран. Но что если ваша\r\nводопроводная вода может излучать свет, например светло-синий или\r\nкрасный? Может, если вы используете Glow Flow Tap.</p><p>&nbsp;</p><p>На носик крана одевается специальная насадка, которая содержит в себе:\r\nфильтр, три батарейки, датчик тепла со светодиодными лампочками.</p><p><img src=\"/files/images/news/p2135ex1.jpg\" border=\"0\" height=\"150\" width=\"150\" /></p><p>&nbsp;</p><p>Когда бежит холодная вода Glow Flow излучает синий цвет, за счет чего\r\nсоздается впечатление, что вода действительно синяя. Когда вы\r\nпереключаетесь на горячую воду срабатывает датчик тепла ( от 32-х\r\nградусов ) и Glow Flow меняет цвет воды на красный, что выглядит\r\nпотрясающе фантастически. Очень полезен в доме, где есть маленькие\r\nдети, которых цвет воды может предостеречь об опасности налить воду не\r\nтой температуры или ненароком обжечься, потрогав её.</p>',1,'2009-08-05 15:04:36','2009-08-05 15:27:57'),
(2,'Мини-колонки Music Balloons','music_balloons','2009-07-11','Мини-колонки Music Balloons для аудио устройств','Мини-колонки Music Balloons для аудио устройств','Мини-колонки Music Balloons для аудио устройств','<p><img style=\"border: 0pt none; margin: 5px; float: left;\" src=\"/files/images/news/Music-Balloons-Speakers-2701.jpg\" alt=\"balloons\" height=\"100\" width=\"84\" /></p><p>Music Balloons (Музыкальные шарики) &ndash; так называются эти забавные и красочные миниатюрные <b>USB-колонки</b> для прослушивания музыки.<span id=\"more-358\"></span></p>\r\n<p>Зарядить <b>мини-колонки</b> можно просто подключив их к\r\nUSB-порту компьютера или ноутбука, подключение же к аудиоустройству\r\nосуществляется через обычный 3,5 мм стереовход.</p>','<p>\r\n\r\nОписание колонок Music Balloons:</p><p>    * Размер: 55 x 55 x 55 мм<br />    * Усилитель: внутренний, 0.7W (8&Omega; 1.0KHz)<br />    * Батарея: заряжаемая через USB<br />    * Время работы: около 2-ух часов / 100mA / 4.2V</p><p><img src=\"/files/images/news/Music-Balloons-Speakers-2701-2.jpg\" alt=\"balloons\" border=\"0\" height=\"325\" width=\"450\" /></p>',1,'2009-02-11 19:17:12','2009-08-05 14:53:43');

/* Table structure for table `orders` */
DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `order_id` bigint(20) NOT NULL auto_increment,
  `delivery_method_id` int(11) default NULL,
  `delivery_price` float(10,2) NOT NULL default '0.00',
  `payment_method_id` int(11) default NULL,
  `payment_status` int(11) NOT NULL default '0',
  `payment_date` datetime NOT NULL,
  `written_off` tinyint(1) NOT NULL,
  `date` datetime default NULL,
  `user_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `address` varchar(255) NOT NULL default '',
  `phone` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL,
  `comment` varchar(1024) NOT NULL,
  `status` int(11) NOT NULL default '0',
  `code` varchar(255) default NULL,
  `payment_details` text NOT NULL,
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`order_id`),
  KEY `login` (`user_id`),
  KEY `written_off` (`written_off`),
  KEY `date` (`date`),
  KEY `status` (`status`),
  KEY `code` (`code`),
  KEY `payment_status` (`payment_status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `orders_products` */
DROP TABLE IF EXISTS `orders_products`;

CREATE TABLE `orders_products` (
  `order_id` int(11) NOT NULL default '0',
  `product_id` int(11) NOT NULL default '0',
  `variant_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL default '',
  `variant_name` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL default '0.00',
  `quantity` int(11) NOT NULL default '0',
  PRIMARY KEY  (`order_id`,`product_id`,`variant_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `payment_methods` */
DROP TABLE IF EXISTS `payment_methods`;

CREATE TABLE `payment_methods` (
  `payment_method_id` int(11) NOT NULL auto_increment,
  `module` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `currency_id` float NOT NULL,
  `params` text NOT NULL,
  `enabled` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`payment_method_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/* dumping data for table `payment_methods` */
insert into `payment_methods` values
(1,'','Курьеру наличными','','1','a:22:{s:17:\"wm_merchant_purse\";s:0:\"\";s:13:\"wm_secret_key\";s:0:\"\";s:14:\"wm_success_url\";s:0:\"\";s:11:\"wm_fail_url\";s:0:\"\";s:15:\"robokassa_login\";s:0:\"\";s:19:\"robokassa_password1\";s:0:\"\";s:19:\"robokassa_password2\";s:0:\"\";s:18:\"robokassa_language\";s:2:\"ru\";s:11:\"merchant_id\";s:0:\"\";s:11:\"terminal_id\";s:0:\"\";s:8:\"gate_url\";s:0:\"\";s:6:\"locale\";s:2:\"hr\";s:12:\"ssl_key_file\";s:0:\"\";s:13:\"ssl_cert_file\";s:0:\"\";s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";}',1),
(2,'webmoney','Webmoney wmz','<p>Оплата через платежную систему <a href=\"http://www.webmoney.ru\">WebMoney</a>. У вас должен быть счет в этой системе для того, чтобы произвести оплату. Сразу после оформления заказа вы будете перенаправлены на специальную страницу системы WebMoney, где сможете произвести платеж в титульных знаках WMZ.</p>','7','a:26:{s:17:\"wm_merchant_purse\";s:13:\"Z210282151782\";s:13:\"wm_secret_key\";s:13:\"testsecretkey\";s:14:\"wm_success_url\";s:3:\"wde\";s:11:\"wm_fail_url\";s:2:\"aa\";s:15:\"robokassa_login\";s:0:\"\";s:19:\"robokassa_password1\";s:0:\"\";s:19:\"robokassa_password2\";s:0:\"\";s:18:\"robokassa_language\";s:2:\"ru\";s:12:\"assist_login\";s:0:\"\";s:16:\"assist_password1\";s:0:\"\";s:16:\"assist_password2\";s:0:\"\";s:15:\"assist_language\";s:2:\"ru\";s:11:\"merchant_id\";s:0:\"\";s:11:\"terminal_id\";s:0:\"\";s:8:\"gate_url\";s:0:\"\";s:6:\"locale\";s:2:\"hr\";s:12:\"ssl_key_file\";s:0:\"\";s:13:\"ssl_cert_file\";s:0:\"\";s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";}',1),
(3,'webmoney','Webmoney wmu','<p>Оплата через платежную систему <a href=\"http://www.webmoney.ru\">WebMoney</a>. У вас должен быть счет в этой системе для того, чтобы произвести оплату.Сразу после оформления заказа вы будете перенаправлены на специальную страницу системы WebMoney, где сможете произвести платеж в титульных знаках WMU.</p>','8','a:26:{s:17:\"wm_merchant_purse\";s:13:\"U495984302762\";s:13:\"wm_secret_key\";s:1:\"c\";s:14:\"wm_success_url\";s:0:\"\";s:11:\"wm_fail_url\";s:0:\"\";s:15:\"robokassa_login\";s:0:\"\";s:19:\"robokassa_password1\";s:0:\"\";s:19:\"robokassa_password2\";s:0:\"\";s:18:\"robokassa_language\";s:2:\"ru\";s:12:\"assist_login\";s:0:\"\";s:16:\"assist_password1\";s:0:\"\";s:16:\"assist_password2\";s:0:\"\";s:15:\"assist_language\";s:2:\"ru\";s:11:\"merchant_id\";s:0:\"\";s:11:\"terminal_id\";s:0:\"\";s:8:\"gate_url\";s:0:\"\";s:6:\"locale\";s:2:\"hr\";s:12:\"ssl_key_file\";s:0:\"\";s:13:\"ssl_cert_file\";s:0:\"\";s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";}',1),
(7,'upc','Банковская карта','<p>Вы можете оплатить заказ с помощью своей банковской карты Visa или MasterCard через Украинский Процессинговый Центр</p>','1','a:26:{s:17:\"wm_merchant_purse\";s:0:\"\";s:13:\"wm_secret_key\";s:0:\"\";s:14:\"wm_success_url\";s:0:\"\";s:11:\"wm_fail_url\";s:0:\"\";s:15:\"robokassa_login\";s:0:\"\";s:19:\"robokassa_password1\";s:0:\"\";s:19:\"robokassa_password2\";s:0:\"\";s:18:\"robokassa_language\";s:2:\"ru\";s:12:\"assist_login\";s:0:\"\";s:16:\"assist_password1\";s:0:\"\";s:16:\"assist_password2\";s:0:\"\";s:15:\"assist_language\";s:2:\"ru\";s:11:\"merchant_id\";s:7:\"1752466\";s:11:\"terminal_id\";s:8:\"E7880266\";s:8:\"gate_url\";s:35:\"https://secure.upc.ua/ecgtest/enter\";s:6:\"locale\";s:2:\"ru\";s:12:\"ssl_key_file\";s:21:\"admin/ssl/1752466.pem\";s:13:\"ssl_cert_file\";s:18:\"admin/ssl/upc.cert\";s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";}',1),
(8,'','Наличными в офисе Автолюкса','','4','a:26:{s:17:\"wm_merchant_purse\";s:0:\"\";s:13:\"wm_secret_key\";s:0:\"\";s:14:\"wm_success_url\";s:0:\"\";s:11:\"wm_fail_url\";s:0:\"\";s:15:\"robokassa_login\";s:0:\"\";s:19:\"robokassa_password1\";s:0:\"\";s:19:\"robokassa_password2\";s:0:\"\";s:18:\"robokassa_language\";s:2:\"ru\";s:12:\"assist_login\";s:0:\"\";s:16:\"assist_password1\";s:0:\"\";s:16:\"assist_password2\";s:0:\"\";s:15:\"assist_language\";s:2:\"ru\";s:11:\"merchant_id\";s:0:\"\";s:11:\"terminal_id\";s:0:\"\";s:8:\"gate_url\";s:0:\"\";s:6:\"locale\";s:2:\"ru\";s:12:\"ssl_key_file\";s:0:\"\";s:13:\"ssl_cert_file\";s:0:\"\";s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";}',1),
(9,'receipt','В отделении банка','<p>Вы можете произвести оплату в любом банке, который принимает платежи от частных лиц.</p>','4','a:26:{s:17:\"wm_merchant_purse\";s:0:\"\";s:13:\"wm_secret_key\";s:0:\"\";s:14:\"wm_success_url\";s:0:\"\";s:11:\"wm_fail_url\";s:0:\"\";s:15:\"robokassa_login\";s:0:\"\";s:19:\"robokassa_password1\";s:0:\"\";s:19:\"robokassa_password2\";s:0:\"\";s:18:\"robokassa_language\";s:2:\"ru\";s:12:\"assist_login\";s:0:\"\";s:16:\"assist_password1\";s:0:\"\";s:16:\"assist_password2\";s:0:\"\";s:15:\"assist_language\";s:2:\"ru\";s:11:\"merchant_id\";s:0:\"\";s:11:\"terminal_id\";s:0:\"\";s:8:\"gate_url\";s:0:\"\";s:6:\"locale\";s:2:\"ru\";s:12:\"ssl_key_file\";s:0:\"\";s:13:\"ssl_cert_file\";s:0:\"\";s:9:\"recipient\";s:69:\"ООО Демострационный интернет магазин\";s:3:\"inn\";s:10:\"1234567890\";s:7:\"account\";s:20:\"34358000900877009090\";s:4:\"bank\";s:60:\"Печерское отделения Приватбанка\";s:3:\"bik\";s:9:\"342897001\";s:21:\"correspondent_account\";s:20:\"11622273744006040024\";s:8:\"banknote\";s:7:\"руб.\";s:5:\"pense\";s:7:\"коп.\";}',1),
(10,'assist','Assist.ru','','4','a:29:{s:17:\"wm_merchant_purse\";s:0:\"\";s:13:\"wm_secret_key\";s:0:\"\";s:14:\"wm_success_url\";s:0:\"\";s:11:\"wm_fail_url\";s:0:\"\";s:15:\"robokassa_login\";s:0:\"\";s:19:\"robokassa_password1\";s:0:\"\";s:19:\"robokassa_password2\";s:0:\"\";s:18:\"robokassa_language\";s:2:\"ru\";s:14:\"assist_shop_id\";s:6:\"346318\";s:12:\"assist_delay\";s:1:\"1\";s:15:\"assist_language\";s:1:\"0\";s:24:\"assist_webmoney_payments\";s:1:\"1\";s:23:\"assist_paycash_payments\";s:1:\"1\";s:25:\"assist_epbeeline_payments\";s:1:\"1\";s:22:\"assist_assist_payments\";s:1:\"1\";s:11:\"merchant_id\";s:0:\"\";s:11:\"terminal_id\";s:0:\"\";s:8:\"gate_url\";s:0:\"\";s:6:\"locale\";s:2:\"ru\";s:12:\"ssl_key_file\";s:0:\"\";s:13:\"ssl_cert_file\";s:0:\"\";s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";}',1),
(11,'robokassa','Робокасса','<p>ROBOKASSA - это сервис, позволяющий принимать платежи в любой электронной валюте, с помощью sms-сообщений, через систему денежных переводов Contact, и через терминалы мгновенной оплаты.</p>','7','a:25:{s:17:\"wm_merchant_purse\";s:0:\"\";s:13:\"wm_secret_key\";s:0:\"\";s:14:\"wm_success_url\";s:0:\"\";s:11:\"wm_fail_url\";s:0:\"\";s:15:\"robokassa_login\";s:7:\"pikusov\";s:19:\"robokassa_password1\";s:12:\"qweqweskiri1\";s:19:\"robokassa_password2\";s:12:\"qweqweskiri2\";s:18:\"robokassa_language\";s:2:\"ru\";s:14:\"assist_shop_id\";s:0:\"\";s:12:\"assist_delay\";s:1:\"0\";s:15:\"assist_language\";s:1:\"0\";s:11:\"merchant_id\";s:0:\"\";s:11:\"terminal_id\";s:0:\"\";s:8:\"gate_url\";s:0:\"\";s:6:\"locale\";s:2:\"hr\";s:12:\"ssl_key_file\";s:0:\"\";s:13:\"ssl_cert_file\";s:0:\"\";s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";}',1);

/* Table structure for table `products` */
DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL default '',
  `category_id` int(11) NOT NULL default '0',
  `brand_id` int(11) default NULL,
  `model` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `body` longtext NOT NULL,
  `enabled` tinyint(1) NOT NULL default '1',
  `hit` tinyint(1) NOT NULL default '0',
  `order_num` int(11) NOT NULL default '0',
  `small_image` varchar(255) NOT NULL default '',
  `large_image` varchar(255) NOT NULL default '',
  `download` varchar(255) NOT NULL,
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`product_id`),
  KEY `url` (`url`),
  KEY `category_id` (`category_id`),
  KEY `brand_id` (`brand_id`),
  KEY `model` (`model`(333)),
  KEY `hit` (`hit`),
  KEY `order_num` (`order_num`),
  KEY `id_index` (`category_id`,`order_num`),
  KEY `date_edit` (`modified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `products_categories` */
DROP TABLE IF EXISTS `products_categories`;

CREATE TABLE `products_categories` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY  (`product_id`,`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `products_comments` */
DROP TABLE IF EXISTS `products_comments`;

CREATE TABLE `products_comments` (
  `comment_id` bigint(20) NOT NULL auto_increment,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `ip` varchar(20) NOT NULL default '',
  `product_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `comment` varchar(1024) NOT NULL,
  PRIMARY KEY  (`comment_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;


/* Table structure for table `products_fotos` */
DROP TABLE IF EXISTS `products_fotos`;

CREATE TABLE `products_fotos` (
  `product_id` int(11) NOT NULL default '0',
  `foto_id` int(11) NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`product_id`,`foto_id`),
  KEY `filename` (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `products_variants` */
DROP TABLE IF EXISTS `products_variants`;

CREATE TABLE `products_variants` (
  `variant_id` bigint(20) NOT NULL auto_increment,
  `product_id` int(11) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float(8,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY  (`variant_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `properties` */
DROP TABLE IF EXISTS `properties`;

CREATE TABLE `properties` (
  `property_id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `in_product` int(1) NOT NULL,
  `in_filter` int(1) NOT NULL,
  `in_compare` int(1) NOT NULL,
  `order_num` int(11) NOT NULL,
  `enabled` int(1) NOT NULL default '1',
  `options` text NOT NULL,
  PRIMARY KEY  (`property_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `properties_categories` */
DROP TABLE IF EXISTS `properties_categories`;

CREATE TABLE `properties_categories` (
  `property_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY  (`property_id`,`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `properties_values` */
DROP TABLE IF EXISTS `properties_values`;

CREATE TABLE `properties_values` (
  `product_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `value` varchar(512) NOT NULL,
  PRIMARY KEY  (`product_id`,`property_id`),
  KEY `value` (`value`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `related_products` */
DROP TABLE IF EXISTS `related_products`;

CREATE TABLE `related_products` (
  `product_id` int(11) NOT NULL,
  `related_sku` varchar(255) NOT NULL,
  PRIMARY KEY  (`product_id`,`related_sku`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


/* Table structure for table `sections` */
DROP TABLE IF EXISTS `sections`;

CREATE TABLE `sections` (
  `section_id` int(11) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL default '',
  `parent` int(11) default NULL,
  `name` varchar(255) NOT NULL default '',
  `header` varchar(255) NOT NULL default '',
  `meta_title` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `body` longtext NOT NULL,
  `menu_id` int(11) NOT NULL default '0',
  `order_num` int(11) NOT NULL default '0',
  `module_id` int(11) default NULL,
  `enabled` tinyint(1) NOT NULL default '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`section_id`),
  KEY `order_num` (`order_num`),
  KEY `module_id` (`module_id`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

/* dumping data for table `sections` */
insert into `sections` values
(103,'404',0,'Страница не найдена','Страница не найдена','Страница не найдена','','','<p>Страница не найдена</p>',1,12,1,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),
(123,'contacts',null,'Контакты','Контакты','Контакты','Москва, шоссе Энтузиастов 45/31, офис 453.   Посмотреть на Яндекс.Картах      Телефон 345-45-54','Контакты','<p>Москва, шоссе Энтузиастов 45/31, офис 453.</p><p>\r\n<a href=\"http://maps.yandex.ru/?text=%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D1%8F%2C%20%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%2C%20%D0%AD%D0%BD%D1%82%D1%83%D0%B7%D0%B8%D0%B0%D1%81%D1%82%D0%BE%D0%B2%20%D1%88%D0%BE%D1%81%D1%81%D0%B5%2C%2051&amp;sll=37.823314%2C55.773034&amp;sspn=0.021955%2C0.009277&amp;ll=37.826161%2C55.77356&amp;spn=0.019637%2C0.006461&amp;l=map\">Посмотреть на&nbsp;Яндекс.Картах</a>\r\n</p><p>&nbsp;</p><p>Телефон 345-45-54</p><p>&nbsp;</p>',2,127,10,1,'0000-00-00 00:00:00','2009-09-01 16:23:04'),
(127,'cat',null,'Каталог','О магазине','Демо','','','<p>Этот магазин является демонстрацией скрипта интернет-магазина Simpla. Все материалы на этом сайте присутствуют исключительно в демострационных целях. Если вы попытаетесь сделать заказ и оплатить его онлайн, платеж пройдет в тестовом режиме, деньги списаны не будут.</p>',2,120,4,1,'0000-00-00 00:00:00','2009-06-01 16:02:11'),
(121,'payment',null,'Оплата','Способы оплаты','Способы оплаты','','','<h2>Наличными курьеру</h2><p>Вы можете оплатить заказ курьеру в гривнах непосредственно в момент доставки. Курьерская доставка осуществляется по Москве на следующий день после принятия заказа.</p><p>&nbsp;</p><p>&nbsp;</p><h2>Webmoney</h2><p>После оформления заказа вы сможете перейти на сайт webmoney для оплаты заказа, где сможете оплатить заказ в автоматическом режиме, а так же проверить наш сертификат продавца.</p><p>&nbsp;</p><p>&nbsp;</p><h2>Карта Visa</h2><p>Вы можете оплатить через Украинский Процессинговый Центр непосредственно после его оформления. Оплата происходит в автоматическом режиме</p><p>&nbsp;</p><p>&nbsp;</p><h2>Наличными в офисе Автолюкса</h2><p>При доставке заказа системой Автолюкс, вы сможете оплатить заказ в их офисе непосредственно в момент получения товаров</p>',2,122,1,1,'0000-00-00 00:00:00','2009-06-01 16:16:11'),
(122,'delivery',null,'Доставка','Способы доставки','Способы доставки','Курьерская доставка по Москве    Курьерская доставка осуществляется на следующий день после оформления заказа ,    если товар есть в наличии. Курьерская доставка осуществляется в пределах Томска и Северска ежедневно с 10.00 до 21.00. Заказ на сумму свыше 300 рублей доставляется бесплатно.   Стоимость бесплатной доставки раcсчитывается от суммы заказа с учтенной скидкой. В случае если сумма заказа после применения скидки менее 300р ,    осуществляется платная доставка.   При сумме заказа менее 30','Способы доставки','<h2>Курьерская доставка по&nbsp;Москве<br /></h2><p><br />Курьерская доставка осуществляется на&nbsp;следующий день после оформления заказа<span style=\"margin-right:-0.2em;\">,</span><span style=\"margin-left:0.2em;\"> </span>если товар есть в&nbsp;наличии. Курьерская доставка осуществляется в&nbsp;пределах Томска и&nbsp;Северска ежедневно с&nbsp;10.00 до&nbsp;21.00. Заказ на&nbsp;сумму свыше 300 рублей доставляется бесплатно. <br /><br />Стоимость бесплатной доставки раcсчитывается от&nbsp;суммы заказа с&nbsp;учтенной скидкой. В&nbsp;случае если сумма заказа после применения скидки менее 300р<span style=\"margin-right:-0.2em;\">,</span><span style=\"margin-left:0.2em;\"> </span>осуществляется платная доставка. <br /><br />При сумме заказа менее 300 рублей стоимость доставки составляет от&nbsp;50 рублей.</p><p>&nbsp;</p><p>&nbsp;</p><h2>Самовывоз<br /></h2><p><br />Удобный<span style=\"margin-right:-0.2em;\">,</span><span style=\"margin-left:0.2em;\"> </span>бесплатный и&nbsp;быстрый способ получения заказа.<br /><br />Адрес офиса: Москва<span style=\"margin-right:-0.2em;\">,</span><span style=\"margin-left:0.2em;\"> </span>ул. Арбат<span style=\"margin-right:-0.2em;\">,</span><span style=\"margin-left:0.2em;\"> </span>1/3<span style=\"margin-right:-0.2em;\">,</span><span style=\"margin-left:0.2em;\"> </span>офис 419.</p><p>&nbsp;</p><p>&nbsp;</p><h2>Доставка с&nbsp;помощью предприятия<span style=\"margin-right:0.44em;\"> </span><span style=\"margin-left:-0.44em;\">&laquo;</span>Автотрейдинг&raquo; <br /></h2><p><br />Удобный и&nbsp;быстрый способ доставки в&nbsp;крупные города России. Посылка доставляется в&nbsp;офис<span style=\"margin-right:0.44em;\"> </span><span style=\"margin-left:-0.44em;\">&laquo;</span>Автотрейдинг&raquo; в&nbsp;Вашем городе. Для получения необходимо предъявить паспорт и&nbsp;номер грузовой декларации<span style=\"margin-right:0.3em;\"> </span><span style=\"margin-left:-0.3em;\">(</span>сообщит наш менеджер после отправки). Посылку желательно получить в&nbsp;течение 24 часов с&nbsp;момента прихода груза<span style=\"margin-right:-0.2em;\">,</span><span style=\"margin-left:0.2em;\"> </span>иначе компания<span style=\"margin-right:0.44em;\"> </span><span style=\"margin-left:-0.44em;\">&laquo;</span>Автотрейдинг&raquo; может взыскать с&nbsp;Вас дополнительную оплату за&nbsp;хранение. Срок доставки и&nbsp;стоимость Вы&nbsp;можете рассчитать на&nbsp;сайте компании.</p><p>&nbsp;</p><h2>Наложенным платежом<br /></h2><p><br />При доставке заказа наложенным платежом с&nbsp;помощью<span style=\"margin-right:0.44em;\"> </span><span style=\"margin-left:-0.44em;\">&laquo;</span>Почты России&raquo;, вы&nbsp;сможете оплатить заказ непосредственно в&nbsp;момент получения товаров.</p>',2,123,1,1,'0000-00-00 00:00:00','2009-09-01 16:16:26'),
(149,'149',null,'Прайс','','','','','',2,149,13,1,'2009-07-02 13:46:12','2009-07-02 13:46:12'),
(150,'150',null,'Контакты','Контакты','Контакты','','','<p>Москва, шоссе Энтузиастов, 45/31, офис 453.</p>\r\n<p>Телефон 345-45-54</p>',3,151,10,1,'2009-07-16 14:59:11','2009-07-16 15:00:02'),
(151,'151',null,'Оплата','Оплата','Оплата','','','<h2>Наличными курьеру</h2><p>Вы можете оплатить заказ курьеру в гривнах непосредственно в момент доставки. Курьерская доставка осуществляется по Москве на следующий день после принятия заказа.</p><p>&nbsp;</p><p>&nbsp;</p><h2>Webmoney</h2><p>После оформления заказа вы сможете перейти на сайт webmoney для оплаты заказа, где сможете оплатить заказ в автоматическом режиме, а так же проверить наш сертификат продавца.</p><p>&nbsp;</p><p>&nbsp;</p><h2>Карта Visa</h2><p>Вы можете оплатить через Украинский Процессинговый Центр непосредственно после его оформления. Оплата происходит в автоматическом режиме</p><p>&nbsp;</p><p>&nbsp;</p><h2>Наличными в офисе Автолюкса</h2><p>При доставке заказа системой Автолюкс, вы сможете оплатить заказ в их офисе непосредственно в момент получения товаров</p>',3,152,1,1,'2009-07-16 15:02:00','2009-07-16 15:02:00'),
(152,'152',null,'Доставка','Доставка','Доставка','','','<h2>Курьерская доставка по Москве<br /></h2><p><br />Курьерская доставка осуществляется на следующий день после оформления заказа, если товар есть в наличии. Курьерская доставка осуществляется в пределах Томска и Северска ежедневно с 10.00 до 21.00. Заказ на сумму свыше 300 рублей доставляется бесплатно.&nbsp;<br /><br />Стоимость бесплатной доставки раcсчитывается от суммы заказа с учтенной скидкой. В случае если сумма заказа после применения скидки менее 300р, осуществляется платная доставка.&nbsp;<br /><br />При сумме заказа менее 300 рублей стоимость доставки составляет от 50 рублей.</p><p>&nbsp;</p><p>&nbsp;</p><h2>Самовывоз<br /></h2><p><br />Удобный, бесплатный и быстрый способ получения заказа.<br /><br />Адрес офиса: Москва, ул. Арбат, 1/3, офис 419.</p><p>&nbsp;</p><p>&nbsp;</p><h2>Доставка с помощью предприятия \"Автотрейдинг\"<br /></h2><p><br />Удобный и быстрый способ доставки в крупные города России. Посылка доставляется в офис \"Автотрейдинг\" в Вашем городе. Для получения необходимо предъявить паспорт и номер грузовой декларации (сообщит наш менеджер после отправки). Посылку желательно получить в течение 24 часов с момента прихода груза, иначе компания \"Автотрейдинг\" может взыскать с Вас дополнительную оплату за хранение. Срок доставки и стоимость Вы можете рассчитать на сайте компании.</p><p>&nbsp;</p><h2>Наложенным платежом<br /></h2><p><br />При доставке заказа наложенным платежом с помощью &laquo;Почты России&raquo;, вы сможете оплатить заказ непосредственно в момент получения товаров.</p>',3,153,1,1,'2009-07-16 15:02:33','2009-07-16 15:02:33'),
(153,'153',null,'Новости','Новости','Новости','','Новости','',3,154,3,1,'2009-07-16 15:03:08','2009-08-28 17:26:08'),
(154,'154',null,'Статьи','Статьи','Статьи','','','',3,155,5,1,'2009-07-16 15:03:25','2009-07-16 15:03:25'),
(155,'155',null,'Вход','Вход','Вход','','','',3,156,8,1,'2009-07-16 15:07:11','2009-07-16 15:07:11'),
(156,'156',null,'Регистрация','Регистрация','Регистрация','','','',3,157,9,1,'2009-07-16 15:07:27','2009-07-16 15:07:27'),
(157,'157',null,'Каталог','Каталог','Каталог','','','<p>Этот магазин является демонстрацией скрипта интернет-магазина Simpla.</p>',3,150,4,1,'2009-07-16 15:08:28','2009-07-16 15:18:33'),
(158,'sitemap',null,'Карта сайта','Карта сайта','','','','',2,158,14,1,'2009-07-21 21:53:44','2009-07-21 21:53:44');

/* Table structure for table `settings` */
DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (`setting_id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

/* dumping data for table `settings` */
insert into `settings` values
(2,'main_section','cat'),
(4,'footer_text','&copy; 2008 Интернет-магазин Кулон'),
(5,'left_text','Мы осуществляем бесплатную доставку по Украине для заказов от 250 грн.'),
(8,'site_name','Демонстрационный интернет-магазин'),
(9,'company_name','Simpla'),
(10,'admin_email','info@simp.la'),
(14,'counters','			<!--LiveInternet counter--><script type=\"text/javascript\"><!--\r\n			document.write(\"<a href=\'http://www.liveinternet.ru/click\' \"+\r\n			\"target=_blank><img src=\'http://counter.yadro.ru/hit?t44.1;r\"+\r\n			escape(document.referrer)+((typeof(screen)==\"undefined\")?\"\":\r\n			\";s\"+screen.width+\"*\"+screen.height+\"*\"+(screen.colorDepth?\r\n			screen.colorDepth:screen.pixelDepth))+\";u\"+escape(document.URL)+\r\n			\";\"+Math.random()+\r\n			\"\' alt=\'\' title=\'LiveInternet\' \"+\r\n			\"border=\'0\' width=\'31\' height=\'31\'><\\/a>\")\r\n			//--></script><!--/LiveInternet-->'),
(22,'product_thumbnail_width','150'),
(23,'product_thumbnail_height','200'),
(24,'product_image_width','300'),
(25,'product_image_height','500'),
(26,'image_quality','100'),
(15,'phones',''),
(27,'csv_import_delimiter',';'),
(28,'csv_import_columns','ctg, brnd, name, prc'),
(29,'file_import_charset','CP1251'),
(30,'theme','default'),
(31,'product_adimage_width','500'),
(32,'product_adimage_height','800'),
(33,'products_num','10'),
(34,'products_num_admin','20'),
(35,'notify_from_email','info@simp.la'),
(36,'file_export_charset','CP1251'),
(37,'csv_export_columns','ctg, brnd, name, prc'),
(38,'csv_export_delimiter',';'),
(3,'main_mobile_section','157'),
(39,'meta_autofill','1');

/* Table structure for table `users` */
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL auto_increment,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `group_id` int(11) NOT NULL default '0',
  `enabled` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`user_id`),
  KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


